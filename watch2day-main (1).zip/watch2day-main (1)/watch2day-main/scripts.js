const API_KEY = 'YOUR_TMDB_API_KEY';
const MOVIE_ENDPOINTS = [
  'https://vidlink.pro/movie/',
  'https://vidsrc.dev/embed/movie/',
  'https://111movies.com/movie/',
  'https://vidjoy.pro/embed/movie/',
  'https://vidsrc.io/embed/movie/'
];

const SERIES_ENDPOINTS = [
  'https://vidsrc.vip/embed/tv/',
  'https://111movies.com/tv/',
  'https://vidlink.pro/tv/'
];

const movieGrid = document.getElementById('movie-grid');
const seriesGrid = document.getElementById('series-grid');
const modal = document.getElementById('modal');
const modalPlayer = document.getElementById('modal-player');
const closeModal = document.getElementById('close-modal');

async function fetchData(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch data');
    return await response.json();
  } catch (error) {
    console.error('Error fetching data:', error);
    return null;
  }
}

function getStarRating(voteAverage) {
  const fullStars = Math.floor(voteAverage / 2);
  const emptyStars = 5 - fullStars;
  return '★'.repeat(fullStars) + '☆'.repeat(emptyStars);
}

async function fetchMovies() {
  const data = await fetchData(`https://api.themoviedb.org/3/discover/movie?api_key=${API_KEY}`);
  if (!data) return;
  movieGrid.innerHTML = data.results.map(movie => `
    <div class="movie-card" onclick="openMovieModal(${movie.id})">
      <img src="https://image.tmdb.org/t/p/w500/${movie.poster_path}" alt="${movie.title}" class="movie-image">
      <div class="rating">${getStarRating(movie.vote_average)}</div>
    </div>
  `).join('');
}

function openMovieModal(movieId) {
  modal.style.display = 'flex';
  modalPlayer.innerHTML = `
    <h3>Watch Movie</h3>
    <iframe src="${MOVIE_ENDPOINTS[0]}${movieId}" frameborder="0" allowfullscreen></iframe>
    <select id="server-select" onchange="changeServer(${movieId})">
      ${MOVIE_ENDPOINTS.map((endpoint, i) => `<option value="${endpoint}">Server ${i + 1}</option>`).join('')}
    </select>
    <div id="adsterra-ad"></div>
  `;
  loadAdsterra();
}

function changeServer(movieId) {
  const server = document.getElementById('server-select').value;
  document.querySelector('iframe').src = `${server}${movieId}`;
}

function loadAdsterra() {
  document.getElementById('adsterra-ad').innerHTML = '<script type="text/javascript" src="//plxxx.adsterra.com/..."><\/script>';
}

closeModal.onclick = () => {
  modal.style.display = 'none';
  modalPlayer.innerHTML = '';
};

fetchMovies();
